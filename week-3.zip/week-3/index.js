/*
Title: Assignment 3 - Restaurant App
Author: Richard Krasso
Date: 1/22/2023
Description: A PDF that describes how to complete Web 330 Assign_3
*/

export * from "./appetizer.js";
export * from "./beverage.js";
export * from "./dessert.js";
export * from "./main-course.js";
export * from "./bill.js";
