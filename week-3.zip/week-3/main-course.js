/*
Title: Assignment 3 - Restaurant App
Author: Richard Krasso
Date: 1/22/2023
Description: A PDF that describes how to complete Web 330 Assign_3
*/
import { Product } from "./product.js";

export class MainCourse extends Product {
  constructor(name, price) {
    super(name, price);
  }
}
