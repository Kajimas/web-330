/*
Title: Assignment 4 - Restaurant App
Author: Richard Krasso
Date: 1/29/2023
Description: A PDF that describes how to complete Web 330 Assign_4
*/

export class FoodModel {
  constructor(id, name, calories) {
    this.id = id;
    this.name = name;
    this.calories = calories;
  }
}
