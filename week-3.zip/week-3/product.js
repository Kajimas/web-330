/*
Title: Assignment 3 - Restaurant App
Author: Richard Krasso
Date: 1/22/2023
Description: A PDF that describes how to complete Web 330 Assign_3
*/

// creates a template for appetizer.js, beverage.js, dessert.js, and main-course.js
export class Product {
  constructor(name, price) {
    this.name = name;
    this.price = price;
  }
}
